// This is a test harness for your module
// You should do something interesting in this harness 
// to test out the module and to provide instructions 
// to users on how to use it by example.


// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white'
});
var label = Ti.UI.createLabel();
win.add(label);
win.open();

var tftModule = require('com.tapfortap.ti');
Ti.API.info("module is => " + tftModule);

var tft = tftModule.createTapForTap();
tft.setEnvironment = "development";
tft.initializeWithApiKey("ACB9E550DDA1679B29401D26EDB4F23B")

if (Ti.Platform.name == "android") {
	var adView = tftModule.createAdView({
		message: "Creating an example Proxy",
		width: 320,
		height: 50,
		top: 75,
		left: 75
	});
	win.add(adView);
	
	 var interstitial = tftModule.createInterstital();
	 interstitial.show();
	 var appWall = tftModule.createAppWall();
	 appWall.show();
}
