// This is a test harness for your module
// You should do something interesting in this harness 
// to test out the module and to provide instructions 
// to users on how to use it by example.


// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white'
});
var label = Ti.UI.createLabel();
win.add(label);
win.open();

var tftModule = require('com.tapfortap.ti');
Ti.API.info("module is => " + tftModule);

var tft = tftModule.createTapForTap();
tft.setEnvironment = "development";
tft.initializeWithApiKey("ACB9E550DDA1679B29401D26EDB4F23B")

if (Ti.Platform.name == "android") {
	var tftModule = require('com.tapfortap.ti');
    Ti.API.info("module is => " + tftModule);

	var tft = tftModule.createTapForTap();
	tft.initializeWithApiKey("YOUR API KEY")
 
	var adView = tftModule.createAdView({
		width: 320,
		height: 50,
		top: 0,
		left: 0
	});
	
	adView.addEventListener("tap", function(d) {
		Ti.API.info("Banner was tapped");
	});
	
	adView.addEventListener("receive", function(d) {
		Ti.API.info("Banner was received");
	});
	
	adView.addEventListener("error", function(d) {
		Ti.API.info("Failed to receive banenr because ", JSON.stringify(d, null, 2));
	});
	
	window.add(adView);
	
	var showAppWallButton = Ti.UI.createButton({
    	title:"Show AppWall",
    	top:80 + 50,
    	height: 50,
    	width: 300
	});

	showAppWallButton.addEventListener("click",function(){
	    var appWall = tftModule.createAppWall();
		appWall.addEventListener("dismiss", function(d) {
			Ti.API.info("AppWall dismissed");
		});
		appWall.show();
	});
	window.add(showAppWallButton);
	
	var showInterstitialButton = Ti.UI.createButton({
    	title:"Show Interstitial",
    	top:80 + 50 + 50 + 10,
    	height: 50,
    	width: 300
	});

	showInterstitialButton.addEventListener("click",function(){
		var interstitial = tftModule.createInterstitial();
		interstitial.addEventListener("dismiss", function(d) {
			Ti.API.info("Interstitial dismissed");
		});
		interstitial.show();
	});
	window.add(showInterstitialButton);
}
